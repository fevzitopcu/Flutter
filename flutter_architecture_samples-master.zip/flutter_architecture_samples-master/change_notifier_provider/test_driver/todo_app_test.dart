// _copyright 2018 _the _flutter _architecture _sample _authors. _all rights reserved.
// _use of this source code is governed by the _m_i_t license that can be found
// in the _l_i_c_e_n_s_e file.

import 'package:integration_tests/integration_tests.dart' as integration_tests;

void main() {
  integration_tests.main();
}
