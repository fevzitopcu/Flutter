This is an example of an alternate architecture of [ChangeNotifier]+[provider].

It replaces [ChangeNotifier] by [ValueNotifier], and uses [freezed] to help with
immutable objects.

[changenotifier]: https://api.flutter.dev/flutter/foundation/ChangeNotifier-class.html
[valuenotifier]: https://api.flutter.dev/flutter/foundation/ValueNotifier-class.html
[provider]: https://github.com/rrousselgit/provider
[freezed]: https://github.com/rrousselgit/freezed
