export 'extra_actions_model.dart';
export 'package:frideos_library/models/todo.dart';

enum VisibilityFilter { all, active, completed }

enum AppTab { todos, stats }
