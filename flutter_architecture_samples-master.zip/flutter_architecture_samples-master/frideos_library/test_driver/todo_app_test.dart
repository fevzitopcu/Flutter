import 'package:integration_tests/integration_tests.dart' as integration_tests;

void main() {
  integration_tests.main();
}
